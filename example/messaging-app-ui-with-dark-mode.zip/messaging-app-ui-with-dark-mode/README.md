# Messaging App UI with Dark Mode

A Pen created on CodePen.

Original URL: [https://codepen.io/Jeanth20/pen/wBwEyvy](https://codepen.io/Jeanth20/pen/wBwEyvy).

Inspired by Alex Banaga
https://dribbble.com/shots/8275108-Facebook-Messenger-Redesign